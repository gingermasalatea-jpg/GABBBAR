export default function Loading() {
  return <div className="flex h-full items-center justify-center text-sm text-slate-500">Loading…</div>;
}
